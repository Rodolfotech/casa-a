<?php
/**
 * Funciones del theme CASA A.
 *
 * @package CASA_A
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function casa_a_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'gallery', 'caption' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );

	register_nav_menus(
		array(
			'principal' => __( 'Menú principal', 'casa-a' ),
		)
	);
}
add_action( 'after_setup_theme', 'casa_a_setup' );

function casa_a_enqueue_assets() {
	wp_enqueue_style( 'casa-a-style', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
}
add_action( 'wp_enqueue_scripts', 'casa_a_enqueue_assets' );

/**
 * Menú de respaldo cuando aún no hay menú asignado.
 */
function casa_a_menu_fallback() {
	echo '<ul class="casa-a-menu">';
	echo '<li><a href="' . esc_url( home_url( '/casa-a/' ) ) . '">' . esc_html__( 'Casa A', 'casa-a' ) . '</a></li>';
	echo '<li><a href="' . esc_url( home_url( '/estudio/' ) ) . '">' . esc_html__( 'Estudio', 'casa-a' ) . '</a></li>';
	echo '<li><a href="' . esc_url( home_url( '/contacto/' ) ) . '">' . esc_html__( 'Contacto', 'casa-a' ) . '</a></li>';
	echo '</ul>';
}

/**
 * Procesa el formulario de contacto de la página Contacto.
 */
function casa_a_contacto_procesar() {
	check_admin_referer( 'casa_a_contacto', 'casa_a_contacto_nonce' );

	$destino = wp_get_referer() ? wp_get_referer() : home_url( '/contacto/' );

	// Campo trampa: los humanos no lo llenan.
	if ( ! empty( $_POST['sitio_web'] ) ) {
		wp_safe_redirect( add_query_arg( 'casa_a_estado', 'ok', $destino ) );
		exit;
	}

	$nombre      = isset( $_POST['nombre'] ) ? sanitize_text_field( wp_unslash( $_POST['nombre'] ) ) : '';
	$telefono    = isset( $_POST['telefono'] ) ? sanitize_text_field( wp_unslash( $_POST['telefono'] ) ) : '';
	$pais        = isset( $_POST['prefijo'] ) ? sanitize_text_field( wp_unslash( $_POST['prefijo'] ) ) : '';
	$email       = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$descripcion = isset( $_POST['descripcion'] ) ? sanitize_textarea_field( wp_unslash( $_POST['descripcion'] ) ) : '';
	$privacidad  = ! empty( $_POST['privacidad'] );
	$promociones = ! empty( $_POST['promociones'] ) ? 'Sí' : 'No';

	if ( '' === $nombre || ! is_email( $email ) || '' === $descripcion || ! $privacidad ) {
		wp_safe_redirect( add_query_arg( 'casa_a_estado', 'error', $destino ) );
		exit;
	}

	$adjunto_ruta = '';
	if ( ! empty( $_FILES['adjunto']['name'] ) && UPLOAD_ERR_OK === $_FILES['adjunto']['error'] ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';

		$archivo = wp_handle_upload(
			$_FILES['adjunto'],
			array(
				'test_form' => false,
				'mimes'     => array(
					'jpg|jpeg' => 'image/jpeg',
					'png'      => 'image/png',
					'pdf'      => 'application/pdf',
				),
			)
		);

		if ( isset( $archivo['error'] ) ) {
			wp_safe_redirect( add_query_arg( 'casa_a_estado', 'archivo', $destino ) );
			exit;
		}

		$adjunto_ruta = $archivo['file'];
	}

	$asunto  = sprintf( __( 'Nueva cotización desde CASA A: %s', 'casa-a' ), $nombre );
	$cuerpo  = sprintf( __( "Nombre: %s\nTeléfono: %s %s\nCorreo: %s\nPromociones: %s\n\nDescripción del proyecto:\n%s", 'casa-a' ), $nombre, $pais, $telefono, $email, $promociones, $descripcion );
	$cabeceras = array( 'Reply-To: ' . $nombre . ' <' . $email . '>' );
	$adjuntos  = $adjunto_ruta ? array( $adjunto_ruta ) : array();

	$enviado = wp_mail( get_option( 'admin_email' ), $asunto, $cuerpo, $cabeceras, $adjuntos );

	// Se borra la copia subida para no dejarla accesible en la carpeta pública de uploads.
	if ( $adjunto_ruta && file_exists( $adjunto_ruta ) ) {
		wp_delete_file( $adjunto_ruta );
	}

	wp_safe_redirect( add_query_arg( 'casa_a_estado', $enviado ? 'ok' : 'fallo', $destino ) );
	exit;
}
add_action( 'admin_post_nopriv_casa_a_contacto', 'casa_a_contacto_procesar' );
add_action( 'admin_post_casa_a_contacto', 'casa_a_contacto_procesar' );
