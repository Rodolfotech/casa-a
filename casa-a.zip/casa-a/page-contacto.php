<?php
/**
 * Plantilla de la página Contacto: redes, reservas, valores y teléfono.
 *
 * @package CASA_A
 */

get_header();
?>
<main class="casa-a-main">
	<div class="casa-a-wrap">
		<?php
		while ( have_posts() ) {
			the_post();
			?>
			<article <?php post_class(); ?>>
				<h1 class="casa-a-entry-title"><?php the_title(); ?></h1>
				<div class="casa-a-content"><?php the_content(); ?></div>
			</article>
			<?php
		}
		?>

		<?php
		$estado = isset( $_GET['casa_a_estado'] ) ? sanitize_key( wp_unslash( $_GET['casa_a_estado'] ) ) : '';
		$avisos = array(
			'ok'      => array( 'casa-a-aviso-ok', __( 'Gracias. Recibimos tu mensaje y te responderemos pronto.', 'casa-a' ) ),
			'error'   => array( 'casa-a-aviso-error', __( 'Revisa los campos obligatorios e intenta de nuevo.', 'casa-a' ) ),
			'archivo' => array( 'casa-a-aviso-error', __( 'El archivo no se pudo subir. Usa JPG, PNG o PDF.', 'casa-a' ) ),
			'fallo'   => array( 'casa-a-aviso-error', __( 'No pudimos enviar el mensaje. Intenta más tarde o escríbenos directamente.', 'casa-a' ) ),
		);
		?>

		<section class="casa-a-formulario" aria-labelledby="casa-a-form-titulo">
			<h2 id="casa-a-form-titulo" class="casa-a-form-titulo"><?php esc_html_e( 'Cuéntanos tu proyecto', 'casa-a' ); ?></h2>

			<?php if ( isset( $avisos[ $estado ] ) ) : ?>
				<p class="casa-a-aviso <?php echo esc_attr( $avisos[ $estado ][0] ); ?>" role="status"><?php echo esc_html( $avisos[ $estado ][1] ); ?></p>
			<?php endif; ?>

			<form class="casa-a-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="casa_a_contacto">
				<?php wp_nonce_field( 'casa_a_contacto', 'casa_a_contacto_nonce' ); ?>

				<div class="casa-a-form-fila">
					<div class="casa-a-campo">
						<label for="casa-a-nombre"><?php esc_html_e( 'Nombre completo', 'casa-a' ); ?> <span aria-hidden="true">*</span></label>
						<input type="text" id="casa-a-nombre" name="nombre" placeholder="<?php esc_attr_e( 'Ej. Juan Pérez', 'casa-a' ); ?>" required autocomplete="name">
					</div>

					<div class="casa-a-campo">
						<label for="casa-a-telefono"><?php esc_html_e( 'Teléfono', 'casa-a' ); ?></label>
						<div class="casa-a-telefono">
							<select name="prefijo" aria-label="<?php esc_attr_e( 'Prefijo telefónico', 'casa-a' ); ?>">
								<option value="+56">🇨🇱 +56</option>
								<option value="+54">🇦🇷 +54</option>
								<option value="+51">🇵🇪 +51</option>
								<option value="+1">🇺🇸 +1</option>
							</select>
							<input type="tel" id="casa-a-telefono" name="telefono" placeholder="8765 4321" autocomplete="tel-national">
						</div>
					</div>
				</div>

				<div class="casa-a-campo">
					<label for="casa-a-email"><?php esc_html_e( 'Correo electrónico', 'casa-a' ); ?> <span aria-hidden="true">*</span></label>
					<input type="email" id="casa-a-email" name="email" placeholder="<?php esc_attr_e( 'tu@correo.com', 'casa-a' ); ?>" required autocomplete="email">
				</div>

				<div class="casa-a-campo">
					<label for="casa-a-descripcion"><?php esc_html_e( 'Descripción del proyecto', 'casa-a' ); ?> <span aria-hidden="true">*</span></label>
					<textarea id="casa-a-descripcion" name="descripcion" rows="6" maxlength="2000" required placeholder="<?php esc_attr_e( 'Cuéntanos detalles de medidas, materiales y plazos…', 'casa-a' ); ?>"></textarea>
					<p class="casa-a-contador"><?php esc_html_e( 'Límite 2000 caracteres', 'casa-a' ); ?></p>
				</div>

				<div class="casa-a-campo">
					<label class="casa-a-adjunto" for="casa-a-adjunto">
						<span class="casa-a-adjunto-texto"><?php esc_html_e( 'Adjuntar imagen o PDF del boceto o producto (opcional)', 'casa-a' ); ?></span>
						<input type="file" id="casa-a-adjunto" name="adjunto" accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf">
					</label>
					<p class="casa-a-nota"><?php esc_html_e( 'Por favor no adjuntes documentos con datos personales sensibles ni cédula de identidad.', 'casa-a' ); ?></p>
				</div>

				<label class="casa-a-check">
					<input type="checkbox" name="privacidad" value="1" required>
					<span><?php esc_html_e( 'He leído y acepto la', 'casa-a' ); ?> <a href="<?php echo esc_url( home_url( '/politica-de-privacidad/' ) ); ?>"><?php esc_html_e( 'Política de Privacidad', 'casa-a' ); ?></a> <?php esc_html_e( 'y los', 'casa-a' ); ?> <a href="<?php echo esc_url( home_url( '/terminos-y-condiciones/' ) ); ?>"><?php esc_html_e( 'Términos y Condiciones', 'casa-a' ); ?></a>.</span>
				</label>

				<label class="casa-a-check">
					<input type="checkbox" name="promociones" value="1">
					<span><?php esc_html_e( '(Opcional) Acepto recibir ofertas y comunicaciones comerciales.', 'casa-a' ); ?></span>
				</label>

				<div class="casa-a-privacidad-aviso">
					<?php esc_html_e( 'Tus datos serán tratados conforme a la ley 21.719 para gestionar tu cotización. Consulta nuestra Política de Privacidad o ejerce tus derechos escribiendo a', 'casa-a' ); ?>
					<a href="mailto:<?php echo esc_attr( get_option( 'admin_email' ) ); ?>"><?php echo esc_html( get_option( 'admin_email' ) ); ?></a>.
				</div>

				<?php /* Campo trampa anti-spam: oculto para personas. */ ?>
				<div class="casa-a-trampa" aria-hidden="true">
					<label>Sitio web <input type="text" name="sitio_web" tabindex="-1" autocomplete="off"></label>
				</div>

				<button type="submit" class="casa-a-boton-enviar"><?php esc_html_e( 'Enviar mensaje', 'casa-a' ); ?> <span aria-hidden="true">→</span></button>
				<p class="casa-a-tiempo"><?php esc_html_e( 'Respondemos entre 24 y 48 horas hábiles.', 'casa-a' ); ?></p>
			</form>
		</section>

		<section class="casa-a-grid" style="margin-top:48px">
			<div class="casa-a-card">
				<h3><?php esc_html_e( 'Redes sociales', 'casa-a' ); ?></h3>
				<p class="casa-a-muted"><?php esc_html_e( 'Agrega aquí los links de Instagram, Facebook y demás redes.', 'casa-a' ); ?></p>
			</div>
			<div class="casa-a-card">
				<h3><?php esc_html_e( 'Reservas', 'casa-a' ); ?></h3>
				<p class="casa-a-muted"><?php esc_html_e( 'Ficha con calendario de reserva. Pendiente de decidir la herramienta (embed externo por defecto).', 'casa-a' ); ?></p>
			</div>
			<div class="casa-a-card">
				<h3><?php esc_html_e( 'Valores', 'casa-a' ); ?></h3>
				<p class="casa-a-muted"><?php esc_html_e( 'Tarifas por espacio y servicio.', 'casa-a' ); ?></p>
			</div>
			<div class="casa-a-card">
				<h3><?php esc_html_e( 'Teléfono', 'casa-a' ); ?></h3>
				<p class="casa-a-muted"><?php esc_html_e( 'Número de contacto directo.', 'casa-a' ); ?></p>
			</div>
		</section>
	</div>
</main>
<?php
get_footer();
