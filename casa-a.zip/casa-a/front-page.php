<?php
/**
 * Portada del theme CASA A.
 *
 * @package CASA_A
 */

get_header();
?>
<main>
	<section class="casa-a-hero">
		<div class="casa-a-wrap">
			<h1>CASA A</h1>
			<p><?php esc_html_e( 'Estudio boutique y hub creativo: campañas fotográficas, producción de video, activaciones de marca, podcast y eventos pequeños.', 'casa-a' ); ?></p>
			<a class="casa-a-button" href="<?php echo esc_url( home_url( '/contacto/' ) ); ?>"><?php esc_html_e( 'Reservar', 'casa-a' ); ?></a>
		</div>
	</section>

	<section class="casa-a-main">
		<div class="casa-a-wrap casa-a-grid">
			<div class="casa-a-card">
				<h3><?php esc_html_e( 'Casa A', 'casa-a' ); ?></h3>
				<p class="casa-a-muted"><?php esc_html_e( 'Conoce la marca y lo que ofrecemos.', 'casa-a' ); ?></p>
				<a href="<?php echo esc_url( home_url( '/casa-a/' ) ); ?>"><?php esc_html_e( 'Ver más', 'casa-a' ); ?></a>
			</div>
			<div class="casa-a-card">
				<h3><?php esc_html_e( 'Estudio', 'casa-a' ); ?></h3>
				<p class="casa-a-muted"><?php esc_html_e( 'Planos, fotos y datos técnicos del espacio.', 'casa-a' ); ?></p>
				<a href="<?php echo esc_url( home_url( '/estudio/' ) ); ?>"><?php esc_html_e( 'Ver más', 'casa-a' ); ?></a>
			</div>
			<div class="casa-a-card">
				<h3><?php esc_html_e( 'Contacto', 'casa-a' ); ?></h3>
				<p class="casa-a-muted"><?php esc_html_e( 'Redes, calendario de reservas y teléfono.', 'casa-a' ); ?></p>
				<a href="<?php echo esc_url( home_url( '/contacto/' ) ); ?>"><?php esc_html_e( 'Ver más', 'casa-a' ); ?></a>
			</div>
		</div>
	</section>
</main>
<?php
get_footer();
