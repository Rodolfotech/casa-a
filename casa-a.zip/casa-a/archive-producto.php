<?php
/**
 * Listado del catálogo de productos.
 *
 * @package CASA_A
 */

get_header();
?>
<main class="casa-a-main">
	<div class="casa-a-wrap">
		<h1 class="casa-a-entry-title"><?php post_type_archive_title(); ?></h1>

		<?php
		$categorias = get_terms(
			array(
				'taxonomy'   => 'categoria_producto',
				'hide_empty' => true,
			)
		);

		if ( ! empty( $categorias ) && ! is_wp_error( $categorias ) ) {
			?>
			<nav aria-label="<?php esc_attr_e( 'Categorías de productos', 'casa-a' ); ?>" style="margin-bottom:32px">
				<ul class="casa-a-menu">
					<?php foreach ( $categorias as $categoria ) : ?>
						<li><a href="<?php echo esc_url( get_term_link( $categoria ) ); ?>"><?php echo esc_html( $categoria->name ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</nav>
			<?php
		}
		?>

		<?php if ( have_posts() ) : ?>
			<div class="casa-a-grid">
				<?php
				while ( have_posts() ) {
					the_post();
					$disponibilidad = get_post_meta( get_the_ID(), 'casa_a_disponibilidad', true );
					?>
					<article class="casa-a-card">
						<?php if ( has_post_thumbnail() ) : ?>
							<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium_large' ); ?></a>
						<?php endif; ?>
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<?php if ( $disponibilidad ) : ?>
							<p class="casa-a-muted"><?php echo esc_html( $disponibilidad ); ?></p>
						<?php endif; ?>
					</article>
					<?php
				}
				?>
			</div>
			<?php the_posts_pagination(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'Todavía no hay productos en el catálogo.', 'casa-a' ); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php
get_footer();
