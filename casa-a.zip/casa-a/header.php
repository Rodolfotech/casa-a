<?php
/**
 * Encabezado del theme CASA A.
 *
 * @package CASA_A
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="casa-a-header">
	<div class="casa-a-wrap">
		<a class="casa-a-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">CASA A</a>
		<nav aria-label="<?php esc_attr_e( 'Navegación principal', 'casa-a' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'principal',
					'container'      => false,
					'menu_class'     => 'casa-a-menu',
					'fallback_cb'    => 'casa_a_menu_fallback',
				)
			);
			?>
		</nav>
	</div>
</header>
