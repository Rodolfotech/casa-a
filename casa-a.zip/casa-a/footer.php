<?php
/**
 * Pie del theme CASA A.
 *
 * @package CASA_A
 */
?>
<footer class="casa-a-footer">
	<div class="casa-a-wrap">
		<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> CASA A. <?php esc_html_e( 'Espacio creativo multidisciplinario.', 'casa-a' ); ?></p>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
